package com.company;

public class Word {
    //フィールド　word meaning
    public String word;
    public String meaning;
    //コンストラクタ
    public Word(){
        this.word = word;
        this.meaning = meaning;
    }
    //メソッド
   public void touroku(){
        System.out.println("単語："+this.word+"意味"+this.meaning);
   }
}
