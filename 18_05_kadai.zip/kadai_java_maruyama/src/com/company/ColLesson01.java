package com.company;


import java.util.ArrayList;


public class ColLesson01 {
    public static void main(String[] args) {
        ArrayList<Word> word_array = new ArrayList<>();
        word_array.add(new Word());
        word_array.add(new Word());

        for (int i = 0;i <= 9;i++){
            System.out.println(array.get(i));
        }
    }
}
